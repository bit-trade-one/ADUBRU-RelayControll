﻿Imports USB_Relay_Controller_Library_MC
Imports Microsoft.Win32.SafeHandles

Public Class Form1

    Private Const DEVICE_CONNECT_MAX_NUM As Integer = 5
    Private Const RELAY5_DEVICE_TYPE As Integer = 0
    Private Const RELAY9_DEVICE_TYPE As Integer = 1
    Private Const RELAY5_RELAY_NUM As Integer = 5
    Private Const RELAY9_RELAY_NUM As Integer = 9
    Private Const RELAY_OFF As Byte = 0
    Private Const RELAY_ON As Byte = 1
    Private chkbx_Relay_Out() As CheckBox
    Private txtbx_Read_Value() As TextBox
    Private chkbx_Relay_Out2() As CheckBox
    Private txtbx_Read_Value2() As TextBox

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        chkbx_Relay_Out = New CheckBox() {CheckBox1, CheckBox2, CheckBox3, CheckBox4, CheckBox5}
        txtbx_Read_Value = New TextBox() {TextBox1, TextBox2, TextBox3, TextBox4, TextBox5}
        chkbx_Relay_Out2 = New CheckBox() {CheckBox11, CheckBox12, CheckBox13, CheckBox14, CheckBox15, CheckBox16, CheckBox17, CheckBox18, CheckBox19}
        txtbx_Read_Value2 = New TextBox() {TextBox11, TextBox12, TextBox13, TextBox14, TextBox15, TextBox16, TextBox17, TextBox18, TextBox19}

        For fi = 1 To DEVICE_CONNECT_MAX_NUM Step 1
            cmbbx_5relay_board_no.Items.Add(String.Format("基板No.{0}", fi))
            cmbbx_9relay_board_no.Items.Add(String.Format("基板No.{0}", fi))
        Next
        cmbbx_5relay_board_no.SelectedIndex = 0
        cmbbx_9relay_board_no.SelectedIndex = 0
    End Sub

    Private Sub btn_allset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_allset.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBRelayController.openUSBRelayController(Me.Handle, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim set_flag(RELAY5_RELAY_NUM - 1) As Byte
                For fi = 0 To (RELAY5_RELAY_NUM - 1) Step 1
                    If chkbx_Relay_Out(fi).Checked = True Then
                        set_flag(fi) = RELAY_ON
                    Else
                        set_flag(fi) = RELAY_OFF
                    End If
                Next
                i_ret = USBRelayController.writeRelayOutputAll(handle_usb_device, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1, set_flag)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1)
            End If
        End Try
    End Sub

    Private Sub btn_set_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click, Button4.Click, Button3.Click, Button2.Click, Button1.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBRelayController.openUSBRelayController(Me.Handle, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim button = CType(sender, Button)
                Dim idx As Integer = Integer.Parse(button.Tag.ToString())
                Dim set_flag As Byte
                If chkbx_Relay_Out(idx).Checked = True Then
                    set_flag = RELAY_ON
                Else
                    set_flag = RELAY_OFF
                End If
                i_ret = USBRelayController.writeRelayOutput(handle_usb_device, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1, idx + 1, set_flag)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1)
            End If
        End Try
    End Sub

    Private Sub btn_read_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_read.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBRelayController.openUSBRelayController(Me.Handle, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim read_out_status(RELAY5_RELAY_NUM - 1) As Byte
                i_ret = USBRelayController.readRelayData(handle_usb_device, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1, read_out_status, RELAY5_RELAY_NUM)
                For fi = 0 To (RELAY5_RELAY_NUM - 1) Step 1
                    txtbx_Read_Value(fi).Text = String.Format("{0}", read_out_status(fi))
                Next
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY5_DEVICE_TYPE, cmbbx_5relay_board_no.SelectedIndex + 1)
            End If
        End Try
    End Sub

    Private Sub btn_allset2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_allset2.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBRelayController.openUSBRelayController(Me.Handle, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim set_flag(RELAY9_RELAY_NUM - 1) As Byte
                For fi = 0 To (RELAY9_RELAY_NUM - 1) Step 1
                    If chkbx_Relay_Out2(fi).Checked = True Then
                        set_flag(fi) = RELAY_ON
                    Else
                        set_flag(fi) = RELAY_OFF
                    End If
                Next
                i_ret = USBRelayController.writeRelayOutputAll(handle_usb_device, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1, set_flag)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1)
            End If
        End Try
    End Sub

    Private Sub btn_set2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click, Button18.Click, Button17.Click, Button16.Click, Button15.Click, Button14.Click, Button13.Click, Button12.Click, Button11.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBRelayController.openUSBRelayController(Me.Handle, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim button = CType(sender, Button)
                Dim idx As Integer = Integer.Parse(button.Tag.ToString())
                Dim set_flag As Byte
                If chkbx_Relay_Out2(idx).Checked = True Then
                    set_flag = RELAY_ON
                Else
                    set_flag = RELAY_OFF
                End If
                i_ret = USBRelayController.writeRelayOutput(handle_usb_device, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1, idx + 1, set_flag)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1)
            End If
        End Try
    End Sub

    Private Sub btn_read2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_read2.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBRelayController.openUSBRelayController(Me.Handle, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim read_out_status(RELAY9_RELAY_NUM - 1) As Byte
                i_ret = USBRelayController.readRelayData(handle_usb_device, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1, read_out_status, RELAY9_RELAY_NUM)
                For fi = 0 To (RELAY9_RELAY_NUM - 1) Step 1
                    txtbx_Read_Value2(fi).Text = String.Format("{0}", read_out_status(fi))
                Next
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY9_DEVICE_TYPE, cmbbx_9relay_board_no.SelectedIndex + 1)
            End If
        End Try
    End Sub
End Class
