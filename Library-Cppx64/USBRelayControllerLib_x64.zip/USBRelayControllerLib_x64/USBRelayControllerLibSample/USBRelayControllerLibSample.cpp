// AgeConfirmationRefDll.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "USBRelayControllerLib.h"

#define DEVICE_ID_NUM	2

#define RELAY_CONNECT_MAX_NUM	0x02	// RELAY�ڑ��ő吔
#define RELAY_DEVICE_ID_MIN		0x00	// RELAY DEVICE ID MIN
#define RELAY_DEVICE_ID_MAX		0x01	// RELAY DEVICE ID MAX
#define RELAY5_DEVICE_ID		0x00	// RELAY5 DEVICE ID
#define RELAY9_DEVICE_ID		0x01	// RELAY9 DEVICE ID
#define RELAY5_NO_MIN			0x01	// RELAY5 NO MIN
#define RELAY5_NO_MAX			0x05	// RELAY5 NO MAX
#define RELAY9_NO_MIN			0x01	// RELAY9 NO MIN
#define RELAY9_NO_MAX			0x09	// RELAY9 NO MAX
#define RELAY5_RELAY_NUM		0x05	// RELAY5 Relay��
#define RELAY9_RELAY_NUM		0x09	// RELAY9 Relay��

int _tmain(int argc, _TCHAR* argv[])
{
	int type = 0;
	int d_id = 0;
	int set_val = 0;
	int i_ret;
	int para1, para2;
	BYTE* para_arry;
	BYTE para_arry5[RELAY5_RELAY_NUM];
	BYTE para_arry9[RELAY9_RELAY_NUM];
	int fi;
	BYTE check_flag = 0;
	clock_t start_time, end_time;

	HMODULE hHandle = GetModuleHandle(0);
	//openUSB(hHandle);
	HANDLE usbHandle[DEVICE_ID_NUM] = {NULL};

	while(1)
	{
		printf_s("\n�������e��I�����ĉ������B\n");
		printf("1:USB�ڑ�\n");
		printf("2:USB�ؒf\n");
		printf("3:Relay�o�͐ݒ�\n");
		printf("4:Relay�S�o�͐ݒ�\n");
		printf("5:Relay�o�͏�Ԏ擾\n");
		printf("99:�I��\n");
		rewind(stdin);
		type = 0;
		printf("�����ԍ� ? = ");
		scanf_s("%d", &type);

		if(type == 99)
		{
			break;
		}

		do{
			printf("Device ID ? (5Relay=0, 9Relay=1) = ");
			scanf_s("%d", &d_id);
		}while(d_id < 0 || DEVICE_ID_NUM <= d_id);



		switch(type)
		{
			case 1:
				start_time = clock();
				usbHandle[d_id] = openUSBRelayController(hHandle, d_id);
				end_time = clock();
				printf("%d\n", usbHandle[d_id]);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 2:
				start_time = clock();
				i_ret = closeUSBRelayController(usbHandle[d_id], d_id);
				end_time = clock();
				usbHandle[d_id] = NULL;
				printf("%d\n", i_ret);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 3:
				printf("Relay No. ? (1�`5 or 1�`9) = ");
				scanf_s("%d", &para1);
				printf("Relay ON/OFF ? (OFF=0, ON=1) = ");
				scanf_s("%d", &para2);
				start_time = clock();
				i_ret = writeRelayOutput(usbHandle[d_id], d_id, para1, para2);
				end_time = clock();
				printf("%d\n", i_ret);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 4:
				check_flag	= 0;
				if(d_id == RELAY5_DEVICE_ID)
				{
					for(fi = 0; fi < RELAY5_RELAY_NUM; fi++)
					{
						printf("Relay%d ON/OFF ? (OFF=0, ON=1) = ", fi+1);
						scanf_s("%d", &para2);
						para_arry5[fi] = (BYTE)(para2 & 0xFF);
					}
					para1 = RELAY5_RELAY_NUM;
					para_arry = para_arry5;
				}
				else if(d_id == RELAY9_DEVICE_ID)
				{
					for(fi = 0; fi < RELAY9_RELAY_NUM; fi++)
					{
						printf("Relay%d ON/OFF ? (OFF=0, ON=1) = ", fi+1);
						scanf_s("%d", &para2);
						para_arry9[fi] = (BYTE)(para2 & 0xFF);
					}
					para1 = RELAY9_RELAY_NUM;
					para_arry = para_arry9;
				}
				else
				{
					check_flag = 1;
				}
				if(check_flag == 0)
				{
					start_time = clock();
					i_ret = writeRelayOutputAll(usbHandle[d_id], d_id, para_arry, para1);
					end_time = clock();
					printf("%d\n", i_ret);
					printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				}
				break;
			case 5:
				check_flag	= 0;
				if(d_id == RELAY5_DEVICE_ID)
				{
					for(fi = 0; fi < RELAY5_RELAY_NUM; fi++)
					{
						para_arry5[fi] = 0;
					}
					para1 = RELAY5_RELAY_NUM;
				}
				else if(d_id == RELAY9_DEVICE_ID)
				{
					for(fi = 0; fi < RELAY9_RELAY_NUM; fi++)
					{
						para_arry9[fi] = 0;
					}
					para1 = RELAY9_RELAY_NUM;
				}
				else
				{
					check_flag = 1;
				}
				if(check_flag == 0)
				{
					start_time = clock();
					i_ret = readRelayData(usbHandle[d_id], d_id, para_arry9, para1);
					end_time = clock();
					for(fi = 0; fi < para1; fi++)
					{
						printf("%d ", para_arry9[fi]);
					}
					printf("\n");
					printf("%d\n", i_ret);
					printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				}
				break;
			default:
				printf("\n�����ԍ�������������܂���I�I�I\n\n");
				break;

		}

	}

	// Open���Ă���USB���N���[�Y����
	for(int fi = 0; fi < DEVICE_ID_NUM; fi++)
	{
		if(usbHandle[d_id] != NULL)
		{
			i_ret = closeUSBRelayController(usbHandle[d_id], fi);
		}
	}

	return 0;
}

