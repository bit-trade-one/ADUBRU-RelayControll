namespace HID_PnP_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.ToggleLEDToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.PushbuttonStateTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.StatusBox_lbl = new System.Windows.Forms.Label();
            this.StatusBox_lbl2 = new System.Windows.Forms.Label();
            this.Status_C_pb = new System.Windows.Forms.PictureBox();
            this.Status_NC_pb = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.colum_lbl = new System.Windows.Forms.Label();
            this.debug01_lbl = new System.Windows.Forms.Label();
            this.debug02_lbl = new System.Windows.Forms.Label();
            this.debug03_lbl = new System.Windows.Forms.Label();
            this.gbx_relay_setup = new System.Windows.Forms.GroupBox();
            this.btn_set_relay9 = new System.Windows.Forms.Button();
            this.btn_set_relay8 = new System.Windows.Forms.Button();
            this.btn_set_relay7 = new System.Windows.Forms.Button();
            this.btn_set_relay6 = new System.Windows.Forms.Button();
            this.btn_set_relay5 = new System.Windows.Forms.Button();
            this.btn_set_relay4 = new System.Windows.Forms.Button();
            this.btn_set_relay3 = new System.Windows.Forms.Button();
            this.btn_set_relay2 = new System.Windows.Forms.Button();
            this.chkbx_Relay9 = new System.Windows.Forms.CheckBox();
            this.chkbx_Relay8 = new System.Windows.Forms.CheckBox();
            this.chkbx_Relay7 = new System.Windows.Forms.CheckBox();
            this.chkbx_Relay6 = new System.Windows.Forms.CheckBox();
            this.chkbx_Relay5 = new System.Windows.Forms.CheckBox();
            this.chkbx_Relay4 = new System.Windows.Forms.CheckBox();
            this.chkbx_Relay3 = new System.Windows.Forms.CheckBox();
            this.chkbx_Relay2 = new System.Windows.Forms.CheckBox();
            this.lbl_Relay_OUtStatus9 = new System.Windows.Forms.Label();
            this.chkbx_Relay1 = new System.Windows.Forms.CheckBox();
            this.lbl_Relay_OUtStatus8 = new System.Windows.Forms.Label();
            this.btn_set_relay1 = new System.Windows.Forms.Button();
            this.lbl_Relay_OUtStatus7 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_Relay_OUtStatus6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_Relay_OUtStatus5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_Relay_OUtStatus4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_Relay_OUtStatus3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_Relay_OUtStatus2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_Relay_OUtStatus1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_set_all_relay = new System.Windows.Forms.Button();
            this.lbl_FWVersion = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.gbx_relay_setup.SuspendLayout();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // ToggleLEDToolTip
            // 
            this.ToggleLEDToolTip.AutomaticDelay = 2000;
            this.ToggleLEDToolTip.AutoPopDelay = 20000;
            this.ToggleLEDToolTip.InitialDelay = 15;
            this.ToggleLEDToolTip.ReshowDelay = 15;
            // 
            // PushbuttonStateTooltip
            // 
            this.PushbuttonStateTooltip.AutomaticDelay = 20;
            this.PushbuttonStateTooltip.AutoPopDelay = 20000;
            this.PushbuttonStateTooltip.InitialDelay = 15;
            this.PushbuttonStateTooltip.ReshowDelay = 15;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 2000;
            this.toolTip1.AutoPopDelay = 20000;
            this.toolTip1.InitialDelay = 15;
            this.toolTip1.ReshowDelay = 15;
            // 
            // toolTip2
            // 
            this.toolTip2.AutomaticDelay = 20;
            this.toolTip2.AutoPopDelay = 20000;
            this.toolTip2.InitialDelay = 15;
            this.toolTip2.ReshowDelay = 15;
            // 
            // StatusBox_lbl
            // 
            this.StatusBox_lbl.AutoSize = true;
            this.StatusBox_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.StatusBox_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl.Location = new System.Drawing.Point(707, 164);
            this.StatusBox_lbl.Name = "StatusBox_lbl";
            this.StatusBox_lbl.Size = new System.Drawing.Size(79, 12);
            this.StatusBox_lbl.TabIndex = 300;
            this.StatusBox_lbl.Text = "�f�o�C�X���ڑ�";
            // 
            // StatusBox_lbl2
            // 
            this.StatusBox_lbl2.AutoSize = true;
            this.StatusBox_lbl2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.StatusBox_lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl2.Location = new System.Drawing.Point(18, 487);
            this.StatusBox_lbl2.Name = "StatusBox_lbl2";
            this.StatusBox_lbl2.Size = new System.Drawing.Size(233, 12);
            this.StatusBox_lbl2.TabIndex = 118;
            this.StatusBox_lbl2.Text = "REVIVE USB, Configuration Tool�N�����܂���";
            // 
            // Status_C_pb
            // 
            this.Status_C_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_C_pb.Image = global::USB_Relay_Controll_CT.Properties.Resources.ON;
            this.Status_C_pb.Location = new System.Drawing.Point(794, 166);
            this.Status_C_pb.Name = "Status_C_pb";
            this.Status_C_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_C_pb.TabIndex = 94;
            this.Status_C_pb.TabStop = false;
            this.Status_C_pb.Visible = false;
            // 
            // Status_NC_pb
            // 
            this.Status_NC_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_NC_pb.Image = global::USB_Relay_Controll_CT.Properties.Resources.OFF;
            this.Status_NC_pb.Location = new System.Drawing.Point(794, 166);
            this.Status_NC_pb.Name = "Status_NC_pb";
            this.Status_NC_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_NC_pb.TabIndex = 95;
            this.Status_NC_pb.TabStop = false;
            this.Status_NC_pb.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.colum_lbl);
            this.groupBox1.Controls.Add(this.debug01_lbl);
            this.groupBox1.Controls.Add(this.debug02_lbl);
            this.groupBox1.Controls.Add(this.debug03_lbl);
            this.groupBox1.Location = new System.Drawing.Point(6, 314);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(860, 146);
            this.groupBox1.TabIndex = 991;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // colum_lbl
            // 
            this.colum_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.colum_lbl.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.colum_lbl.Location = new System.Drawing.Point(6, 15);
            this.colum_lbl.Name = "colum_lbl";
            this.colum_lbl.Size = new System.Drawing.Size(848, 24);
            this.colum_lbl.TabIndex = 991;
            this.colum_lbl.Text = "label1";
            // 
            // debug01_lbl
            // 
            this.debug01_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug01_lbl.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.debug01_lbl.Location = new System.Drawing.Point(6, 48);
            this.debug01_lbl.Name = "debug01_lbl";
            this.debug01_lbl.Size = new System.Drawing.Size(848, 24);
            this.debug01_lbl.TabIndex = 992;
            this.debug01_lbl.Text = "label1";
            // 
            // debug02_lbl
            // 
            this.debug02_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug02_lbl.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.debug02_lbl.Location = new System.Drawing.Point(6, 81);
            this.debug02_lbl.Name = "debug02_lbl";
            this.debug02_lbl.Size = new System.Drawing.Size(848, 24);
            this.debug02_lbl.TabIndex = 993;
            this.debug02_lbl.Text = "label1";
            // 
            // debug03_lbl
            // 
            this.debug03_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug03_lbl.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.debug03_lbl.Location = new System.Drawing.Point(6, 114);
            this.debug03_lbl.Name = "debug03_lbl";
            this.debug03_lbl.Size = new System.Drawing.Size(848, 24);
            this.debug03_lbl.TabIndex = 994;
            this.debug03_lbl.Text = "label1";
            // 
            // gbx_relay_setup
            // 
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay9);
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay8);
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay7);
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay6);
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay5);
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay4);
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay3);
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay2);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay9);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay8);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay7);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay6);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay5);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay4);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay3);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay2);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus9);
            this.gbx_relay_setup.Controls.Add(this.chkbx_Relay1);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus8);
            this.gbx_relay_setup.Controls.Add(this.btn_set_relay1);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus7);
            this.gbx_relay_setup.Controls.Add(this.label14);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus6);
            this.gbx_relay_setup.Controls.Add(this.label13);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus5);
            this.gbx_relay_setup.Controls.Add(this.label12);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus4);
            this.gbx_relay_setup.Controls.Add(this.label11);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus3);
            this.gbx_relay_setup.Controls.Add(this.label10);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus2);
            this.gbx_relay_setup.Controls.Add(this.label9);
            this.gbx_relay_setup.Controls.Add(this.lbl_Relay_OUtStatus1);
            this.gbx_relay_setup.Controls.Add(this.label8);
            this.gbx_relay_setup.Controls.Add(this.label7);
            this.gbx_relay_setup.Controls.Add(this.label6);
            this.gbx_relay_setup.Controls.Add(this.label1);
            this.gbx_relay_setup.Controls.Add(this.label5);
            this.gbx_relay_setup.Controls.Add(this.label2);
            this.gbx_relay_setup.Controls.Add(this.btn_set_all_relay);
            this.gbx_relay_setup.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.gbx_relay_setup.Location = new System.Drawing.Point(15, 12);
            this.gbx_relay_setup.Name = "gbx_relay_setup";
            this.gbx_relay_setup.Size = new System.Drawing.Size(815, 148);
            this.gbx_relay_setup.TabIndex = 100;
            this.gbx_relay_setup.TabStop = false;
            this.gbx_relay_setup.Text = "�����[�ݒ�";
            // 
            // btn_set_relay9
            // 
            this.btn_set_relay9.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay9.Location = new System.Drawing.Point(600, 118);
            this.btn_set_relay9.Name = "btn_set_relay9";
            this.btn_set_relay9.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay9.TabIndex = 179;
            this.btn_set_relay9.Tag = "8";
            this.btn_set_relay9.Text = "�ݒ�";
            this.btn_set_relay9.UseVisualStyleBackColor = true;
            this.btn_set_relay9.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // btn_set_relay8
            // 
            this.btn_set_relay8.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay8.Location = new System.Drawing.Point(540, 118);
            this.btn_set_relay8.Name = "btn_set_relay8";
            this.btn_set_relay8.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay8.TabIndex = 178;
            this.btn_set_relay8.Tag = "7";
            this.btn_set_relay8.Text = "�ݒ�";
            this.btn_set_relay8.UseVisualStyleBackColor = true;
            this.btn_set_relay8.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // btn_set_relay7
            // 
            this.btn_set_relay7.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay7.Location = new System.Drawing.Point(480, 118);
            this.btn_set_relay7.Name = "btn_set_relay7";
            this.btn_set_relay7.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay7.TabIndex = 177;
            this.btn_set_relay7.Tag = "6";
            this.btn_set_relay7.Text = "�ݒ�";
            this.btn_set_relay7.UseVisualStyleBackColor = true;
            this.btn_set_relay7.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // btn_set_relay6
            // 
            this.btn_set_relay6.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay6.Location = new System.Drawing.Point(420, 118);
            this.btn_set_relay6.Name = "btn_set_relay6";
            this.btn_set_relay6.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay6.TabIndex = 176;
            this.btn_set_relay6.Tag = "5";
            this.btn_set_relay6.Text = "�ݒ�";
            this.btn_set_relay6.UseVisualStyleBackColor = true;
            this.btn_set_relay6.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // btn_set_relay5
            // 
            this.btn_set_relay5.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay5.Location = new System.Drawing.Point(360, 118);
            this.btn_set_relay5.Name = "btn_set_relay5";
            this.btn_set_relay5.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay5.TabIndex = 175;
            this.btn_set_relay5.Tag = "4";
            this.btn_set_relay5.Text = "�ݒ�";
            this.btn_set_relay5.UseVisualStyleBackColor = true;
            this.btn_set_relay5.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // btn_set_relay4
            // 
            this.btn_set_relay4.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay4.Location = new System.Drawing.Point(300, 118);
            this.btn_set_relay4.Name = "btn_set_relay4";
            this.btn_set_relay4.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay4.TabIndex = 174;
            this.btn_set_relay4.Tag = "3";
            this.btn_set_relay4.Text = "�ݒ�";
            this.btn_set_relay4.UseVisualStyleBackColor = true;
            this.btn_set_relay4.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // btn_set_relay3
            // 
            this.btn_set_relay3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay3.Location = new System.Drawing.Point(240, 118);
            this.btn_set_relay3.Name = "btn_set_relay3";
            this.btn_set_relay3.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay3.TabIndex = 173;
            this.btn_set_relay3.Tag = "2";
            this.btn_set_relay3.Text = "�ݒ�";
            this.btn_set_relay3.UseVisualStyleBackColor = true;
            this.btn_set_relay3.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // btn_set_relay2
            // 
            this.btn_set_relay2.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay2.Location = new System.Drawing.Point(180, 118);
            this.btn_set_relay2.Name = "btn_set_relay2";
            this.btn_set_relay2.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay2.TabIndex = 172;
            this.btn_set_relay2.Tag = "1";
            this.btn_set_relay2.Text = "�ݒ�";
            this.btn_set_relay2.UseVisualStyleBackColor = true;
            this.btn_set_relay2.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // chkbx_Relay9
            // 
            this.chkbx_Relay9.AutoSize = true;
            this.chkbx_Relay9.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay9.Location = new System.Drawing.Point(625, 92);
            this.chkbx_Relay9.Name = "chkbx_Relay9";
            this.chkbx_Relay9.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay9.TabIndex = 159;
            this.chkbx_Relay9.Tag = "8";
            this.chkbx_Relay9.UseVisualStyleBackColor = true;
            // 
            // chkbx_Relay8
            // 
            this.chkbx_Relay8.AutoSize = true;
            this.chkbx_Relay8.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay8.Location = new System.Drawing.Point(565, 92);
            this.chkbx_Relay8.Name = "chkbx_Relay8";
            this.chkbx_Relay8.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay8.TabIndex = 158;
            this.chkbx_Relay8.Tag = "7";
            this.chkbx_Relay8.UseVisualStyleBackColor = true;
            // 
            // chkbx_Relay7
            // 
            this.chkbx_Relay7.AutoSize = true;
            this.chkbx_Relay7.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay7.Location = new System.Drawing.Point(505, 92);
            this.chkbx_Relay7.Name = "chkbx_Relay7";
            this.chkbx_Relay7.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay7.TabIndex = 157;
            this.chkbx_Relay7.Tag = "6";
            this.chkbx_Relay7.UseVisualStyleBackColor = true;
            // 
            // chkbx_Relay6
            // 
            this.chkbx_Relay6.AutoSize = true;
            this.chkbx_Relay6.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay6.Location = new System.Drawing.Point(445, 92);
            this.chkbx_Relay6.Name = "chkbx_Relay6";
            this.chkbx_Relay6.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay6.TabIndex = 156;
            this.chkbx_Relay6.Tag = "5";
            this.chkbx_Relay6.UseVisualStyleBackColor = true;
            // 
            // chkbx_Relay5
            // 
            this.chkbx_Relay5.AutoSize = true;
            this.chkbx_Relay5.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay5.Location = new System.Drawing.Point(385, 92);
            this.chkbx_Relay5.Name = "chkbx_Relay5";
            this.chkbx_Relay5.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay5.TabIndex = 155;
            this.chkbx_Relay5.Tag = "4";
            this.chkbx_Relay5.UseVisualStyleBackColor = true;
            // 
            // chkbx_Relay4
            // 
            this.chkbx_Relay4.AutoSize = true;
            this.chkbx_Relay4.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay4.Location = new System.Drawing.Point(325, 92);
            this.chkbx_Relay4.Name = "chkbx_Relay4";
            this.chkbx_Relay4.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay4.TabIndex = 154;
            this.chkbx_Relay4.Tag = "3";
            this.chkbx_Relay4.UseVisualStyleBackColor = true;
            // 
            // chkbx_Relay3
            // 
            this.chkbx_Relay3.AutoSize = true;
            this.chkbx_Relay3.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay3.Location = new System.Drawing.Point(265, 92);
            this.chkbx_Relay3.Name = "chkbx_Relay3";
            this.chkbx_Relay3.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay3.TabIndex = 153;
            this.chkbx_Relay3.Tag = "2";
            this.chkbx_Relay3.UseVisualStyleBackColor = true;
            // 
            // chkbx_Relay2
            // 
            this.chkbx_Relay2.AutoSize = true;
            this.chkbx_Relay2.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay2.Location = new System.Drawing.Point(205, 92);
            this.chkbx_Relay2.Name = "chkbx_Relay2";
            this.chkbx_Relay2.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay2.TabIndex = 152;
            this.chkbx_Relay2.Tag = "1";
            this.chkbx_Relay2.UseVisualStyleBackColor = true;
            // 
            // lbl_Relay_OUtStatus9
            // 
            this.lbl_Relay_OUtStatus9.Location = new System.Drawing.Point(600, 56);
            this.lbl_Relay_OUtStatus9.Name = "lbl_Relay_OUtStatus9";
            this.lbl_Relay_OUtStatus9.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus9.TabIndex = 139;
            this.lbl_Relay_OUtStatus9.Text = "OFF";
            this.lbl_Relay_OUtStatus9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // chkbx_Relay1
            // 
            this.chkbx_Relay1.AutoSize = true;
            this.chkbx_Relay1.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkbx_Relay1.Location = new System.Drawing.Point(145, 92);
            this.chkbx_Relay1.Name = "chkbx_Relay1";
            this.chkbx_Relay1.Size = new System.Drawing.Size(15, 14);
            this.chkbx_Relay1.TabIndex = 151;
            this.chkbx_Relay1.Tag = "0";
            this.chkbx_Relay1.UseVisualStyleBackColor = true;
            // 
            // lbl_Relay_OUtStatus8
            // 
            this.lbl_Relay_OUtStatus8.Location = new System.Drawing.Point(540, 56);
            this.lbl_Relay_OUtStatus8.Name = "lbl_Relay_OUtStatus8";
            this.lbl_Relay_OUtStatus8.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus8.TabIndex = 138;
            this.lbl_Relay_OUtStatus8.Text = "OFF";
            this.lbl_Relay_OUtStatus8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_set_relay1
            // 
            this.btn_set_relay1.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_set_relay1.Location = new System.Drawing.Point(120, 118);
            this.btn_set_relay1.Name = "btn_set_relay1";
            this.btn_set_relay1.Size = new System.Drawing.Size(60, 24);
            this.btn_set_relay1.TabIndex = 171;
            this.btn_set_relay1.Tag = "0";
            this.btn_set_relay1.Text = "�ݒ�";
            this.btn_set_relay1.UseVisualStyleBackColor = true;
            this.btn_set_relay1.Click += new System.EventHandler(this.btn_set_relay_Click);
            // 
            // lbl_Relay_OUtStatus7
            // 
            this.lbl_Relay_OUtStatus7.Location = new System.Drawing.Point(480, 56);
            this.lbl_Relay_OUtStatus7.Name = "lbl_Relay_OUtStatus7";
            this.lbl_Relay_OUtStatus7.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus7.TabIndex = 137;
            this.lbl_Relay_OUtStatus7.Text = "OFF";
            this.lbl_Relay_OUtStatus7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(600, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 19);
            this.label14.TabIndex = 119;
            this.label14.Text = "9";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_Relay_OUtStatus6
            // 
            this.lbl_Relay_OUtStatus6.Location = new System.Drawing.Point(420, 56);
            this.lbl_Relay_OUtStatus6.Name = "lbl_Relay_OUtStatus6";
            this.lbl_Relay_OUtStatus6.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus6.TabIndex = 136;
            this.lbl_Relay_OUtStatus6.Text = "OFF";
            this.lbl_Relay_OUtStatus6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(540, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 19);
            this.label13.TabIndex = 118;
            this.label13.Text = "8";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_Relay_OUtStatus5
            // 
            this.lbl_Relay_OUtStatus5.Location = new System.Drawing.Point(360, 56);
            this.lbl_Relay_OUtStatus5.Name = "lbl_Relay_OUtStatus5";
            this.lbl_Relay_OUtStatus5.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus5.TabIndex = 135;
            this.lbl_Relay_OUtStatus5.Text = "OFF";
            this.lbl_Relay_OUtStatus5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(480, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 19);
            this.label12.TabIndex = 117;
            this.label12.Text = "7";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_Relay_OUtStatus4
            // 
            this.lbl_Relay_OUtStatus4.Location = new System.Drawing.Point(300, 56);
            this.lbl_Relay_OUtStatus4.Name = "lbl_Relay_OUtStatus4";
            this.lbl_Relay_OUtStatus4.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus4.TabIndex = 134;
            this.lbl_Relay_OUtStatus4.Text = "OFF";
            this.lbl_Relay_OUtStatus4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(420, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 19);
            this.label11.TabIndex = 116;
            this.label11.Text = "6";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_Relay_OUtStatus3
            // 
            this.lbl_Relay_OUtStatus3.Location = new System.Drawing.Point(240, 56);
            this.lbl_Relay_OUtStatus3.Name = "lbl_Relay_OUtStatus3";
            this.lbl_Relay_OUtStatus3.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus3.TabIndex = 133;
            this.lbl_Relay_OUtStatus3.Text = "OFF";
            this.lbl_Relay_OUtStatus3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(360, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 19);
            this.label10.TabIndex = 115;
            this.label10.Text = "5";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_Relay_OUtStatus2
            // 
            this.lbl_Relay_OUtStatus2.Location = new System.Drawing.Point(180, 56);
            this.lbl_Relay_OUtStatus2.Name = "lbl_Relay_OUtStatus2";
            this.lbl_Relay_OUtStatus2.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus2.TabIndex = 132;
            this.lbl_Relay_OUtStatus2.Text = "OFF";
            this.lbl_Relay_OUtStatus2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(300, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 19);
            this.label9.TabIndex = 114;
            this.label9.Text = "4";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_Relay_OUtStatus1
            // 
            this.lbl_Relay_OUtStatus1.Location = new System.Drawing.Point(120, 56);
            this.lbl_Relay_OUtStatus1.Name = "lbl_Relay_OUtStatus1";
            this.lbl_Relay_OUtStatus1.Size = new System.Drawing.Size(60, 19);
            this.lbl_Relay_OUtStatus1.TabIndex = 131;
            this.lbl_Relay_OUtStatus1.Text = "OFF";
            this.lbl_Relay_OUtStatus1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(240, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 19);
            this.label8.TabIndex = 113;
            this.label8.Text = "3";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(180, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 19);
            this.label7.TabIndex = 112;
            this.label7.Text = "2";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(120, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 19);
            this.label6.TabIndex = 111;
            this.label6.Text = "1";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(30, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 24);
            this.label1.TabIndex = 130;
            this.label1.Text = "���";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(134, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 19);
            this.label5.TabIndex = 102;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(30, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 24);
            this.label2.TabIndex = 150;
            this.label2.Text = "�o��";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btn_set_all_relay
            // 
            this.btn_set_all_relay.Location = new System.Drawing.Point(686, 69);
            this.btn_set_all_relay.Name = "btn_set_all_relay";
            this.btn_set_all_relay.Size = new System.Drawing.Size(109, 37);
            this.btn_set_all_relay.TabIndex = 199;
            this.btn_set_all_relay.Text = "�ꊇ�ݒ�";
            this.btn_set_all_relay.UseVisualStyleBackColor = true;
            this.btn_set_all_relay.Click += new System.EventHandler(this.btn_set_all_relay_Click);
            // 
            // lbl_FWVersion
            // 
            this.lbl_FWVersion.AutoSize = true;
            this.lbl_FWVersion.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_FWVersion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.lbl_FWVersion.Location = new System.Drawing.Point(18, 164);
            this.lbl_FWVersion.Name = "lbl_FWVersion";
            this.lbl_FWVersion.Size = new System.Drawing.Size(79, 12);
            this.lbl_FWVersion.TabIndex = 994;
            this.lbl_FWVersion.Text = "�f�o�C�X���ڑ�";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 500);
            this.Controls.Add(this.lbl_FWVersion);
            this.Controls.Add(this.gbx_relay_setup);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.StatusBox_lbl2);
            this.Controls.Add(this.StatusBox_lbl);
            this.Controls.Add(this.Status_C_pb);
            this.Controls.Add(this.Status_NC_pb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(894, 538);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Configuration Tool ver 1.0.0";
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.gbx_relay_setup.ResumeLayout(false);
            this.gbx_relay_setup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.ToolTip ToggleLEDToolTip;
        private System.Windows.Forms.ToolTip PushbuttonStateTooltip;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.PictureBox Status_C_pb;
        private System.Windows.Forms.PictureBox Status_NC_pb;
        private System.Windows.Forms.Label StatusBox_lbl;
        private System.Windows.Forms.Label StatusBox_lbl2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label colum_lbl;
        private System.Windows.Forms.Label debug01_lbl;
        private System.Windows.Forms.Label debug02_lbl;
        private System.Windows.Forms.Label debug03_lbl;
        private System.Windows.Forms.GroupBox gbx_relay_setup;
        private System.Windows.Forms.Button btn_set_all_relay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkbx_Relay1;
        private System.Windows.Forms.Button btn_set_relay1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_set_relay9;
        private System.Windows.Forms.Button btn_set_relay8;
        private System.Windows.Forms.Button btn_set_relay7;
        private System.Windows.Forms.Button btn_set_relay6;
        private System.Windows.Forms.Button btn_set_relay5;
        private System.Windows.Forms.Button btn_set_relay4;
        private System.Windows.Forms.Button btn_set_relay3;
        private System.Windows.Forms.Button btn_set_relay2;
        private System.Windows.Forms.CheckBox chkbx_Relay9;
        private System.Windows.Forms.CheckBox chkbx_Relay8;
        private System.Windows.Forms.CheckBox chkbx_Relay7;
        private System.Windows.Forms.CheckBox chkbx_Relay6;
        private System.Windows.Forms.CheckBox chkbx_Relay5;
        private System.Windows.Forms.CheckBox chkbx_Relay4;
        private System.Windows.Forms.CheckBox chkbx_Relay3;
        private System.Windows.Forms.CheckBox chkbx_Relay2;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus9;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus8;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus7;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus6;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus5;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus4;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus3;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus2;
        private System.Windows.Forms.Label lbl_Relay_OUtStatus1;
        private System.Windows.Forms.Label lbl_FWVersion;
    }
}

