﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32.SafeHandles;
using USB_Relay_Controller_Library;

namespace USB_Relay_Controller_sample
{
    public partial class Form1 : Form
    {
        const int RELAY5_DEVICE_ID = 0;
        const int RELAY9_DEVICE_ID = 1;
        const int RELAY5_RELAY_NUM = 5;
        const int RELAY9_RELAY_NUM = 9;
        const byte RELAY_OFF = 0;
        const byte RELAY_ON = 1;
        CheckBox[] chkbx_Relay_Out;
        TextBox[] txtbx_Read_Value;
        CheckBox[] chkbx_Relay_Out2;
        TextBox[] txtbx_Read_Value2;

        public Form1()
        {
            InitializeComponent();

            chkbx_Relay_Out = new CheckBox[RELAY5_RELAY_NUM] { checkBox1, checkBox2, checkBox3, checkBox4, checkBox5 };
            txtbx_Read_Value = new TextBox[RELAY5_RELAY_NUM] { textBox1, textBox2, textBox3, textBox4, textBox5 };
            chkbx_Relay_Out2 = new CheckBox[RELAY9_RELAY_NUM] { checkBox6, checkBox7, checkBox8, checkBox9, checkBox10, checkBox11, checkBox12, checkBox13, checkBox14 };
            txtbx_Read_Value2 = new TextBox[RELAY9_RELAY_NUM] { textBox20, textBox19, textBox18, textBox17, textBox16, textBox15, textBox14, textBox13, textBox12 };

        }

        private void btn_allset_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBRelayController.openUSBRelayController(this.Handle, RELAY5_DEVICE_ID);
                if (handle_usb_device != null)
                {
                    byte[] set_flag = new byte[RELAY5_RELAY_NUM];
                    for (int fi = 0; fi < set_flag.Length; fi++)
                    {
                        if (chkbx_Relay_Out[fi].Checked == true)
                        {
                            set_flag[fi] = RELAY_ON;
                        }
                        else
                        {
                            set_flag[fi] = RELAY_OFF;
                        }
                    }
                    i_ret = USBRelayController.writeRelayOutputAll(handle_usb_device, RELAY5_DEVICE_ID, set_flag);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY5_DEVICE_ID);
                }
            }
        }

        private void btn_set_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                int idx = int.Parse(((Button)sender).Tag.ToString());
                // USB DEVICEオープン
                handle_usb_device = USBRelayController.openUSBRelayController(this.Handle, RELAY5_DEVICE_ID);
                if (handle_usb_device != null)
                {
                    byte set_flag = RELAY_OFF;
                    if (chkbx_Relay_Out[idx].Checked == true)
                    {
                        set_flag = RELAY_ON;
                    }
                    else
                    {
                        set_flag = RELAY_OFF;
                    }
                    i_ret = USBRelayController.writeRelayOutput(handle_usb_device, RELAY5_DEVICE_ID, idx + 1, set_flag);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY5_DEVICE_ID);
                }
            }
        }

        private void btn_read_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBRelayController.openUSBRelayController(this.Handle, RELAY5_DEVICE_ID);
                if (handle_usb_device != null)
                {
                    byte[] read_out_status = new byte[RELAY5_RELAY_NUM];
                    i_ret = USBRelayController.readRelayData(handle_usb_device, RELAY5_DEVICE_ID, ref read_out_status, RELAY5_RELAY_NUM);
                    for (int fi = 0; fi < RELAY5_RELAY_NUM; fi++)
                    {
                        txtbx_Read_Value[fi].Text = read_out_status[fi].ToString();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY5_DEVICE_ID);
                }
            }
        }

        private void btn_allset2_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBRelayController.openUSBRelayController(this.Handle, RELAY9_DEVICE_ID);
                if (handle_usb_device != null)
                {
                    byte[] set_flag = new byte[RELAY9_RELAY_NUM];
                    for (int fi = 0; fi < set_flag.Length; fi++)
                    {
                        if (chkbx_Relay_Out2[fi].Checked == true)
                        {
                            set_flag[fi] = RELAY_ON;
                        }
                        else
                        {
                            set_flag[fi] = RELAY_OFF;
                        }
                    }
                    i_ret = USBRelayController.writeRelayOutputAll(handle_usb_device, RELAY9_DEVICE_ID, set_flag);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY9_DEVICE_ID);
                }
            }
        }

        private void btn_set2_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                int idx = int.Parse(((Button)sender).Tag.ToString());
                // USB DEVICEオープン
                handle_usb_device = USBRelayController.openUSBRelayController(this.Handle, RELAY9_DEVICE_ID);
                if (handle_usb_device != null)
                {
                    byte set_flag = RELAY_OFF;
                    if (chkbx_Relay_Out2[idx].Checked == true)
                    {
                        set_flag = RELAY_ON;
                    }
                    else
                    {
                        set_flag = RELAY_OFF;
                    }
                    i_ret = USBRelayController.writeRelayOutput(handle_usb_device, RELAY9_DEVICE_ID, idx + 1, set_flag);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY9_DEVICE_ID);
                }
            }
        }

        private void btn_read2_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBRelayController.openUSBRelayController(this.Handle, RELAY9_DEVICE_ID);
                if (handle_usb_device != null)
                {
                    byte[] read_out_status = new byte[RELAY9_RELAY_NUM];
                    i_ret = USBRelayController.readRelayData(handle_usb_device, RELAY9_DEVICE_ID, ref read_out_status, RELAY9_RELAY_NUM);
                    for (int fi = 0; fi < RELAY9_RELAY_NUM; fi++)
                    {
                        txtbx_Read_Value2[fi].Text = read_out_status[fi].ToString();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBRelayController.closeUSBRelayController(handle_usb_device, RELAY9_DEVICE_ID);
                }
            }
        }
    }
}
