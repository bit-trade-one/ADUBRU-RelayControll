// dllmain.cpp : DLL �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
#include "stdafx.h"

extern BOOL AttachedState[DEVICE_ID_NUM];
extern HANDLE ReadWriteHandleToUSBDevice[DEVICE_ID_NUM];

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		for(int fi = 0; fi < DEVICE_ID_NUM; fi++)
		{
			AttachedState[fi] = FALSE;
			ReadWriteHandleToUSBDevice[fi] = INVALID_HANDLE_VALUE;
		}
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		for(int fi = 0; fi < DEVICE_ID_NUM; fi++)
		{
			if(ReadWriteHandleToUSBDevice[fi] != INVALID_HANDLE_VALUE)
			{
				CloseHandle(ReadWriteHandleToUSBDevice[fi]);
			}
		}
		break;
	}
	return TRUE;
}

