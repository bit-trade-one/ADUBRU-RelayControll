//USBRelayControllerLib.h
#include "stdafx.h"

#ifdef __cplusplus
#define EXPORT extern "C" __declspec (dllexport)
#else
#define EXPORT __declspec (dllexport)
#endif

EXPORT HANDLE __stdcall openUSBRelayController(HANDLE hRecipient, int device_id);
EXPORT int __stdcall closeUSBRelayController(HANDLE HandleToUSBDevice, int device_id);
EXPORT int __stdcall writeRelayOutput(HANDLE HandleToUSBDevice, int device_id, int relay_no, BYTE output_flag);
EXPORT int __stdcall writeRelayOutputAll(HANDLE HandleToUSBDevice, int device_id, BYTE* output_flag, int out_flag_len);
EXPORT int __stdcall readRelayData(HANDLE HandleToUSBDevice, int device_id, BYTE* output_status, int read_relay_num);


